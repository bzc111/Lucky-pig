package briup.hello;

public class hello {
   public String say(String name) {
	   return "hello "+name+"one";
   }
}
